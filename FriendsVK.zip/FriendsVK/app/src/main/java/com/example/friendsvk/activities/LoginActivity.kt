package com.example.friends_vk.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.arellomobile.mvp.MvpAppCompatActivity
import com.example.friends_vk.R
import com.example.friends_vk.views.LoginView

class LoginActivity : MvpAppCompatActivity , LoginView{
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_activity)
    }

    override fun startLoading() {
        TODO("Not yet implemented")
    }

    override fun endLoading() {
        TODO("Not yet implemented")
    }

    override fun showError(): String {
        TODO("Not yet implemented")
    }

    override fun loadFriends() {
        TODO("Not yet implemented")
    }
}