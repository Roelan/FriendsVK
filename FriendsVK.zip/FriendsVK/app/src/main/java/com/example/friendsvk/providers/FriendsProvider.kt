package com.example.friends_vk.providers

class FriendsProvider {
}