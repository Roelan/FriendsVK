package com.example.friends_vk.models

class FriendModel(name: String, surname: String, city: String?, avatar: String?, isOnline: Boolean) {
}