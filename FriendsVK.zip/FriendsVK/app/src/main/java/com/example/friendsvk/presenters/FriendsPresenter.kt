package com.example.friends_vk.presenters

import com.arellomobile.mvp.InjectViewState
import com.arellomobile.mvp.MvpPresenter
import com.example.friends_vk.views.FriendsView

@InjectViewState
class FriendsPresenter : MvpPresenter<FriendsView>() {
}