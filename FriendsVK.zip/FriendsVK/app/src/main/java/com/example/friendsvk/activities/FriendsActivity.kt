package com.example.friends_vk.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.friends_vk.R

class FriendsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_friends)
    }
}